import React, { Component } from 'react';
import {StyleSheet, View, TouchableOpacity, Image } from 'react-native';
import * as Location from 'expo-location';
import MapView, { Marker } from 'react-native-maps';
import * as Permissions from 'expo-permissions';




class Mapa extends Component {

  constructor(props) {
    super(props);
    this.state={
      region: null,
      }
      this._getLocationAsync();
    }

  
  _getLocationAsync = async () =>{
    let { status } = await Permissions.askAsync(Permissions.LOCATION);
    if (status !== 'granted')
      console.log('A permissão para acessar a localização foi negada.');

    let location = await Location.getCurrentPositionAsync ({enabledHighAccuracy: true});
    let region = {
      latitude: location.coords.latitude,
      longitude: location.coords.longitude,
      latitudeDelta: 0.005,
      longitudeDelta: 0.005,
    }
    this.setState({region: region})
  }
  
//  enviasocorro =  () =>{
  
    //var amqp = require('amqplib/callback_api');

   //// amqp.connect('amqp://localhost', function(error0, connection) {
     // if (error0) {
    //    throw error0;
     // }
    //  connection.createChannel(function(error1, channel) {
     //   if (error1) {
      //    throw error1;
     //  }
    // var exchange = 'SOS';
     //   var msg = process.argv.slice(2).join(' ') || 'Hello World!';
    
    //   channel.assertExchange(exchange, 'fanout', {
    //     durable: false
    //    });
    //    channel.publish(exchange, '', Buffer.from(msg));
    ////    console.log(" [x] Sent %s", msg);
     // });
    
     //setTimeout(function() { 
    //    connection.close(); 
    //   process.exit(0); 
    //  }, 500);
  // });
  
  
 //}


  
  render() {
    return (
  <View style = {styles.container}>
        <MapView
            initialRegion={this.state.region}
            showUserLocation={true}
            showsCompass={true}
            rotateEnabled={false}
            style={{flex:1}}
          >  
         </MapView>

         <View style={styles.bottom}>
            <TouchableOpacity
           // onPress={() => 
            //  this.enviasocorro()
           // } 
            >
                <Image
                style={styles.button}
                source={require('../images/logoapp.png')}
                />
            </TouchableOpacity>
       </View>

    </View>
    );
}
}
export default Mapa;

   

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',

    
  },

  bottom: {
   
    position: 'absolute',//use absolute position to show button on top of the map
    top: '85%', //for center align
    alignSelf: 'center' //for align to right
    
  },
  button: {
    alignItems: 'center',
    backgroundColor: 'transparent',
    padding:2,
    width: 120,
   height: 120
  },
  
});
