import React, {Component} from 'react';


import { StyleSheet, Text, View, ImageBackground, Image, TextInput, Dimensions,TouchableOpacity } from 'react-native';

import bgImage from '../images/backg.jpg'
import logo from '../images/capa.png'
import Icon from 'react-native-vector-icons/Ionicons'

const {width: WIDTH} = Dimensions.get('window')

export default class Examples extends Component{


  constructor(){
    super()
    this.state ={
      showPass: true,
      press: false,
      press2: false,
      showPass2: false,
      Email: '',
      SenhaUm: '',
      SenhaDois: '',
      UserName: '',
     // Name: '',
    }
  }

  InsertUserToServer = () =>{
 
    fetch('18.218.249.157/cadastrar', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({

      user_name : this.state.TextInput_Name,

      user_pass : this.state.TextInput_Pass,

      user_passCon : this.state.TextInput_PassCon,

      user_email: this.state.TextInput_Email,

    //  user_nomeReal: this.state.TextInput_NomeReal,

 
    })

    })
       
}



  showPass=()=>{
    if (this.state.press==false){
      this.setState({showPass: false, press:true})
    }else{
      this.setState({showPass: true, press:false})
    }
  }



  showPass2=()=>{
    if (this.state.press==false){
      this.setState({showPass2: false, press2:true})
    }else{
      this.setState({showPass2: true, press2:false})
    }
  }


  enviaForm=()=>{
    this.props.navigation.navigate('MapaScreen')
    this.InsertUserToServer()
  }



  render(){
  return (
      <ImageBackground source={bgImage} style={styles.backgroundContainer}>
       <View style = {styles.logoContainer}>  
          <Image source = {logo} style= {styles.logo} />
          <Text style={styles.Logotexto}> Registre-se na Bees </Text>
        </View>


    

        <View style={styles.inputContainerdebug}>
          <Icon name={'ios-person'} size={28} 
          style={styles.inputIconsenha}/>
      
          <TextInput
          style={styles.input}
            placeholder={'Nome do usuário'}
            onChangeText={ TextInputValue => this.setState({ TextInput_Name : TextInputValue }) }

            placeholderTextColor={'rgba(255,255,255,0.7)'}
            underlineColorAndroid='transparent'
          />
        </View>




        <View stytle={styles.inputContainer}>
          <Icon name={'ios-at'} size={28} 
          style={styles.inputIcon}/>
      
          <TextInput
          style={styles.input}
            placeholder={'Email'}
            onChangeText={ TextInputValue => this.setState({ TextInput_Email : TextInputValue }) }

            placeholderTextColor={'rgba(255, 255, 255, 0.7)'}
            underlineColorAndroid='transparent'
          />
        </View>




        <View style={styles.inputContainer}>
          <Icon name={'ios-lock'} size={28} 
          style={styles.inputIconsenha}/>
      
          <TextInput
          style={styles.input}
            placeholder={'Senha'}
            onChangeText={ TextInputValue => this.setState({ TextInput_Pass : TextInputValue }) }

            secureTextEntry={this.state.showPass}
            placeholderTextColor={'rgba(255, 255, 255, 0.7)'}
            underlineColorAndroid='transparent'
          />

          <TouchableOpacity style={styles.btnEye}
          onPress={this.showPass.bind(this)}
          >
            <Icon name={this.state.press ==false ? 'ios-eye' : 'ios-eye-off'} size={26} color={'rgba(255, 255, 255, 0.7)'}/>
          </TouchableOpacity>
        </View>



        <View style={styles.inputContainer}>

          <Icon name={'ios-lock'} size={28} 
          style={styles.inputIconsenha}/>
      
          <TextInput
          style={styles.input}
            placeholder={'Repita sua senha'}
            onChangeText={ TextInputValue => this.setState({ TextInput_PassCon : TextInputValue }) }

            secureTextEntry={this.state.showPass2}
            placeholderTextColor={'rgba(255, 255, 255, 0.7)'}
            underlineColorAndroid='transparent'
          />

          <TouchableOpacity style={styles.btnEye}
          onPress={this.showPass2.bind(this)}
          >
            <Icon name={this.state.press2 ==false ? 'ios-eye' : 'ios-eye-off'} size={26} color={'rgba(255, 255, 255, 0.7)'}/>
          </TouchableOpacity>
        </View>



        <TouchableOpacity style={styles.btnlogin}
        onPress={() => 
        this.enviaForm()
        }  
        >
          <Text style={styles.textologin}>Registrar</Text>
        </TouchableOpacity>

       </ImageBackground>
    );
  }
}

const styles = StyleSheet.create({
  backgroundContainer: {
    flex: 1,
    width: null,
    height: null,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    width: 180,
    height: 180
  },
    logoContainer: {
    alignItems: 'center',
    marginBottom: 30
    },
    Logotexto: {
      color: 'black',
      fontSize: 20,
      fontWeight:'500',
      marginTop:7,
      marginBottom:3,
      opacity: 0.5,
    },
    input:{
      width: WIDTH-55,
      height: 45,
      borderRadius: 25,
      fontSize: 16,
      paddingLeft: 45,
      backgroundColor: 'rgba(0, 0, 0, 0.35)',
      color: 'rgba(255, 255, 255, 0.7)',
      marginHorizontal: 25,
    },
    inputIcon:{
      position:'absolute',
      top: 8,
      left: 37,
    },
    inputIconsenha:{
      position:'absolute',
      top: 15,
      left: 37,
    },
    inputContainer:{
      paddingTop: 8,
    },
    inputContainerdebug:{
      paddingTop: 8,
      paddingBottom: 8
    },
    btnEye:{
      position: 'absolute',
      top:18,
      right:37,
    },
    btnlogin:{
      width: WIDTH-55,
      height: 45,
      borderRadius: 25,
      backgroundColor: '#432577',
      justifyContent: 'center',
      marginTop: 20
    },
    textologin:{
      color:'rgba(255, 255, 255, 0.7)',
      fontSize: 16,
      textAlign:'center',
    },
    
});
