import React, {Component} from 'react';

import { StyleSheet, Text, View, ImageBackground, Image, Dimensions,TouchableOpacity } from 'react-native';

import bgImage from '../images/backg.jpg'
import logo from '../images/capa.png'


const {width: WIDTH} = Dimensions.get('window')

export default class Examples extends Component{





  render(){
  return (
      <ImageBackground source={bgImage} style={styles.backgroundContainer}>
       <View style = {styles.logoContainer}>  
          <Image source = {logo} style= {styles.logo} />
          <Text style={styles.Logotexto}>   Bem vindo a Bees, para usar nosso aplicativo, você precisa de uma conta</Text>
        </View>
        
        

       
      
        <View style={{flex: 1, flexDirection: 'row',marginTop:80,}}>
          <View>
            
               <TouchableOpacity style={styles.btnlogin2}
                onPress={() => this.props.navigation.navigate('LoginScreen')}
               >
               <Text style={styles.textologin}>Login </Text>
               </TouchableOpacity>
           </View>
         <View>
            <TouchableOpacity style={styles.btnlogin2}
            onPress={() => this.props.navigation.navigate('RegistroScreen')}>
            <Text style={styles.textologin}>Criar uma conta</Text>
            </TouchableOpacity> 
         </View>
      </View>
        
       </ImageBackground>
    );
  }
}

const styles = StyleSheet.create({
  backgroundContainer: {
    flex: 5,
    width: null,
    height: null,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    width: 180,
    height: 180
  },
    logoContainer: {
    alignItems: 'center',
    marginBottom: 50
    },
    Logotexto: {
      color: 'black',
      fontSize: 20,
      fontWeight:'500',
      marginTop:7,
      marginBottom:3,
      opacity: 0.5,
    },
    btnlogin:{
      width: WIDTH-55,
      height: 45,
      borderRadius: 25,
      backgroundColor: '#432577',
      justifyContent: 'center',
      marginTop: 20
    },
    btnlogin2:{
      width: WIDTH-190,
      height: 45,
      borderRadius: 25,
      backgroundColor: '#432577',
      justifyContent: 'center',
      marginTop: 20,
      marginLeft: 2
    },
    textologin:{
      color:'rgba(255, 255, 255, 0.7)',
      fontSize: 16,
      textAlign:'center',
    },
    
});
