import React from 'react';
import { StyleSheet, Text, View } from 'react-native';


import {  createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack'


import InitialScreen from './src/telaprimaria'
import LoginScreen from './src/login'
import RegistroScreen from './src/registro'
import MapaScreen from './src/mapa'



const AppNavigator = createStackNavigator({
  InitialScreen: {screen : InitialScreen},
  LoginScreen: {screen : LoginScreen},
  RegistroScreen: {screen : RegistroScreen},
  MapaScreen: {screen : MapaScreen},


});

export default createAppContainer(AppNavigator);

